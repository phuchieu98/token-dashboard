﻿# Token Dashboard - gỡ cài đặt: xoá lối tắt và gỡ plugin token-meter.
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $lnk = Join-Path $dir 'Token Dashboard.lnk'
  if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Host "Đã xoá $lnk" -ForegroundColor Green }
}
$iconDir = Join-Path $env:LOCALAPPDATA 'TokenDashboard'
if (Test-Path $iconDir) { Remove-Item $iconDir -Recurse -Force }

$claude = (Get-Command claude -ErrorAction SilentlyContinue).Source
if (-not $claude) {
  $b = Get-ChildItem "$env:LOCALAPPDATA\Claude-Data" -Recurse -Filter claude.exe -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match '\\claude-code\\' } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($b) { $claude = $b.FullName }
}
if ($claude) {
  & $claude plugin uninstall token-meter@token-dashboard 2>&1 | Out-Host
  Write-Host 'Đã gỡ plugin token-meter (nếu có).' -ForegroundColor Green
} else {
  Write-Host 'Không tìm thấy Claude Code; bỏ qua bước gỡ plugin.' -ForegroundColor Yellow
}
Write-Host 'Xong.'
