@echo off
chcp 65001 >nul
title Token Dashboard - cai dat
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
