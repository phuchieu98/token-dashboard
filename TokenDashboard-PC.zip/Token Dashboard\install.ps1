﻿# Token Dashboard - bộ cài cho máy tính Windows
#  1. Tạo lối tắt "Token Dashboard" trên Desktop và Start Menu (mở app dạng cửa sổ riêng).
#  2. Cài plugin token-meter cho Claude Code (nếu máy có Claude Code).
param([switch]$NoPlugin, [switch]$NoShortcut)

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

$AppUrl = 'https://phuchieu98.github.io/token-dashboard/'
$Market = 'phuchieu98/token-dashboard'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Say($text, $color = 'Gray') { Write-Host $text -ForegroundColor $color }

Say ''
Say '=== Token Dashboard - cài đặt cho máy tính ===' 'Cyan'
Say ''

# ---------- 1. Lối tắt mở app ----------
if (-not $NoShortcut) {
  Say '[1/2] Tạo lối tắt mở app...' 'White'
  $browsers = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
  )
  $browser = $browsers | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  $icon = Join-Path $Here 'token-dashboard.ico'
  $places = @(
    [Environment]::GetFolderPath('Desktop'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '')
  )
  $shell = New-Object -ComObject WScript.Shell
  foreach ($dir in $places) {
    if (-not (Test-Path $dir)) { continue }
    $lnk = $shell.CreateShortcut((Join-Path $dir 'Token Dashboard.lnk'))
    if ($browser) {
      # Mở app thành cửa sổ riêng, không có thanh địa chỉ.
      $lnk.TargetPath = $browser
      $lnk.Arguments = "--app=$AppUrl"
    } else {
      $lnk.TargetPath = $AppUrl
    }
    if (Test-Path $icon) {
      $installedIcon = Join-Path $env:LOCALAPPDATA 'TokenDashboard\token-dashboard.ico'
      New-Item -ItemType Directory -Force (Split-Path $installedIcon) | Out-Null
      Copy-Item $icon $installedIcon -Force
      $lnk.IconLocation = $installedIcon
    }
    $lnk.Description = 'Theo dõi token Claude đã dùng'
    $lnk.Save()
  }
  if ($browser) { Say ("    Đã tạo lối tắt trên Desktop và Start Menu (mở bằng " + (Split-Path $browser -Leaf) + ').') 'Green' }
  else { Say '    Đã tạo lối tắt (mở bằng trình duyệt mặc định).' 'Green' }
}

# ---------- 2. Plugin token-meter cho Claude Code ----------
if (-not $NoPlugin) {
  Say ''
  Say '[2/2] Cài plugin token-meter cho Claude Code...' 'White'
  $claude = $null
  $cmd = Get-Command claude -ErrorAction SilentlyContinue
  if ($cmd) { $claude = $cmd.Source }
  if (-not $claude) {
    $cands = @("$env:USERPROFILE\.local\bin\claude.exe", "$env:APPDATA\npm\claude.cmd") | Where-Object { Test-Path $_ }
    if ($cands) { $claude = $cands | Select-Object -First 1 }
  }
  if (-not $claude) {
    # Claude Code đi kèm ứng dụng Claude trên máy tính.
    $bundled = Get-ChildItem "$env:LOCALAPPDATA\Claude-Data" -Recurse -Filter claude.exe -ErrorAction SilentlyContinue |
      Where-Object { $_.FullName -match '\\claude-code\\' } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($bundled) { $claude = $bundled.FullName }
  }

  # A token-meter already running as a local mod would count everything twice.
  $devMod = Get-ChildItem "$env:USERPROFILE\.claude\dev-mods" -Directory -ErrorAction SilentlyContinue |
    ForEach-Object { Join-Path $_.FullName 'token-meter' } | Where-Object { Test-Path $_ } | Select-Object -First 1
  if ($devMod) {
    Say "    Máy này đã có token-meter dạng mod ($devMod); bỏ qua để không đếm hai lần." 'Yellow'
  } elseif (-not $claude) {
    Say '    Không tìm thấy Claude Code trên máy này.' 'Yellow'
    Say '    Cài bằng tay trong ứng dụng Claude (tab Code): bấm + cạnh ô nhập -> Plugins ->' 'Yellow'
    Say "    Add marketplace -> nhập $Market -> Add plugin ở mục token-meter." 'Yellow'
  } else {
    Say "    Dùng: $claude" 'DarkGray'
    $installed = & $claude plugin list 2>$null | Out-String
    if ($installed -match 'token-meter') {
      Say '    Plugin token-meter đã có, đang cập nhật bản mới nhất...' 'White'
      & $claude plugin marketplace update token-dashboard 2>&1 | Out-Host
      & $claude plugin update token-meter@token-dashboard 2>&1 | Out-Host
    } else {
      & $claude plugin install token-meter --marketplace $Market --scope user 2>&1 | Out-Host
    }
    if ($LASTEXITCODE -eq 0) { Say '    Đã cài plugin token-meter. Mở lại Claude Code để plugin chạy.' 'Green' }
    else { Say '    Cài plugin chưa thành công. Xem thông báo phía trên, hoặc cài bằng tay theo HUONG-DAN.txt.' 'Yellow' }
  }
}

Say ''
Say '=== Xong. Việc còn lại: ===' 'Cyan'
Say '  1. Mở "Token Dashboard" trên Desktop, đăng nhập bằng tài khoản Google.'
Say '  2. Menu T -> Liên kết tài khoản -> "+ Liên kết thêm tài khoản Claude" -> sao chép mã.'
Say '  3. Trong Claude Code gõ:  /token-meter link <mã> <tên máy>'
Say ''
