@echo off
chcp 65001 >nul
title Token Dashboard - go cai dat
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
echo.
pause
